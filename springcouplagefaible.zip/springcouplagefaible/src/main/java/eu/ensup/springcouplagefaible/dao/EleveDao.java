package eu.ensup.springcouplagefaible.dao;

import java.util.List;

import eu.ensup.springcouplagefaible.domaine.Eleve;

public class EleveDao implements IEleveDao {

	public void createStudent(Eleve eleve) {

		 System.out.println("creation de l'�l�ve");
	}

	public Eleve getEleveById(int id) {

		 System.out.println("recup�ration de l'�l�ve dont l'ID est :" + id);
		 return new Eleve("jean", "pierre");
	}
	
	public void delete(Eleve eleve) {

		 System.out.println("suppression de l'�l�ve");
	}
	public List<Eleve> getAll() {

		 System.out.println("recup�ration de tout les eleves");
		return null;
	}
	
	public void initialisation() {
		System.out.println("Cr�ation de l'objet DAO");
	}
	
	public void destruction() {
		System.out.println("Destruction de l'objet DAO");
	}
	
}

package eu.ensup.springcouplagefaible.dao;

import java.util.List;

import eu.ensup.springcouplagefaible.domaine.Eleve;

public interface IEleveDao {

	void createStudent(Eleve eleve);

	Eleve getEleveById(int id);

	void delete(Eleve eleve);

	List<Eleve> getAll();

}